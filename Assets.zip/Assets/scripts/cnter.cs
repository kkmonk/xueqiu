﻿using UnityEngine;
using System.Collections;

public class cnter : MonoBehaviour {
    public static int goldCnt;
    public static int xuerenCnt;
    // Use this for initialization
    void Start () {
        goldCnt = 0;
        xuerenCnt = 0;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
