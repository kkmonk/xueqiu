﻿using UnityEngine;
using System.Collections;

public class stop : MonoBehaviour {

	public static bool zt;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
