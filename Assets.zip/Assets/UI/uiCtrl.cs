﻿using UnityEngine;
using System.Collections;

public class uiCtrl : MonoBehaviour {
    public AudioSource play;
    public AudioSource exitGame;
    void Start()
    {
        Screen.sleepTimeout = SleepTimeout.NeverSleep;
    }
    public void StartPlay()
    {
        play.Play();
        Application.LoadLevelAsync("playGame");
    }
    public void ExitGame()
    {
        Application.Quit();
    }
    public void ZhuCaiDan()
    {
        Application.LoadLevel("welcome");
    }
    public void ReStart()
    {
        Application.LoadLevel("playGame");  
    }
	public void AoubtUs()
	{
		Application.LoadLevel ("aboutus");
	}
}
